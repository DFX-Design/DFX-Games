﻿
namespace Airline
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.A1 = new System.Windows.Forms.RadioButton();
            this.B1 = new System.Windows.Forms.RadioButton();
            this.C1 = new System.Windows.Forms.RadioButton();
            this.D1 = new System.Windows.Forms.RadioButton();
            this.E1 = new System.Windows.Forms.RadioButton();
            this.F1 = new System.Windows.Forms.RadioButton();
            this.G1 = new System.Windows.Forms.RadioButton();
            this.H1 = new System.Windows.Forms.RadioButton();
            this.I1 = new System.Windows.Forms.RadioButton();
            this.J1 = new System.Windows.Forms.RadioButton();
            this.J2 = new System.Windows.Forms.RadioButton();
            this.I2 = new System.Windows.Forms.RadioButton();
            this.H2 = new System.Windows.Forms.RadioButton();
            this.G2 = new System.Windows.Forms.RadioButton();
            this.F2 = new System.Windows.Forms.RadioButton();
            this.E2 = new System.Windows.Forms.RadioButton();
            this.D2 = new System.Windows.Forms.RadioButton();
            this.C2 = new System.Windows.Forms.RadioButton();
            this.B2 = new System.Windows.Forms.RadioButton();
            this.A2 = new System.Windows.Forms.RadioButton();
            this.J4 = new System.Windows.Forms.RadioButton();
            this.I4 = new System.Windows.Forms.RadioButton();
            this.H4 = new System.Windows.Forms.RadioButton();
            this.G4 = new System.Windows.Forms.RadioButton();
            this.F4 = new System.Windows.Forms.RadioButton();
            this.E4 = new System.Windows.Forms.RadioButton();
            this.D4 = new System.Windows.Forms.RadioButton();
            this.C4 = new System.Windows.Forms.RadioButton();
            this.B4 = new System.Windows.Forms.RadioButton();
            this.A4 = new System.Windows.Forms.RadioButton();
            this.J3 = new System.Windows.Forms.RadioButton();
            this.I3 = new System.Windows.Forms.RadioButton();
            this.H3 = new System.Windows.Forms.RadioButton();
            this.G3 = new System.Windows.Forms.RadioButton();
            this.F3 = new System.Windows.Forms.RadioButton();
            this.E3 = new System.Windows.Forms.RadioButton();
            this.D3 = new System.Windows.Forms.RadioButton();
            this.C3 = new System.Windows.Forms.RadioButton();
            this.B3 = new System.Windows.Forms.RadioButton();
            this.A3 = new System.Windows.Forms.RadioButton();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.seatLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(57, 21);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(137, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Customer Information";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(27, 51);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "First Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(11, 72);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Middle Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(27, 94);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "Last Name";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(4, 117);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(95, 17);
            this.label5.TabIndex = 4;
            this.label5.Text = "Street Address";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(57, 139);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(32, 17);
            this.label6.TabIndex = 5;
            this.label6.Text = "City";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(52, 159);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(38, 17);
            this.label7.TabIndex = 6;
            this.label7.Text = "State";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(62, 183);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(27, 17);
            this.label8.TabIndex = 7;
            this.label8.Text = "Zip";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(3, 207);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(97, 17);
            this.label9.TabIndex = 8;
            this.label9.Text = "Phone Number";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(3, 229);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(100, 17);
            this.label10.TabIndex = 9;
            this.label10.Text = "E-Mail Address";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(257, 21);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(112, 17);
            this.label11.TabIndex = 10;
            this.label11.Text = "Flight Information";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(249, 49);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(39, 17);
            this.label12.TabIndex = 11;
            this.label12.Text = "From";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(249, 74);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(23, 17);
            this.label13.TabIndex = 12;
            this.label13.Text = "To";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(246, 123);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(43, 17);
            this.label14.TabIndex = 13;
            this.label14.Text = "Flight:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(481, 21);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(91, 17);
            this.label15.TabIndex = 14;
            this.label15.Text = "Seat Selection";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(104, 50);
            this.textBox1.Margin = new System.Windows.Forms.Padding(2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(142, 20);
            this.textBox1.TabIndex = 55;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(104, 73);
            this.textBox2.Margin = new System.Windows.Forms.Padding(2);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(142, 20);
            this.textBox2.TabIndex = 56;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(102, 95);
            this.textBox3.Margin = new System.Windows.Forms.Padding(2);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(142, 20);
            this.textBox3.TabIndex = 57;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(102, 118);
            this.textBox4.Margin = new System.Windows.Forms.Padding(2);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(142, 20);
            this.textBox4.TabIndex = 58;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(102, 140);
            this.textBox5.Margin = new System.Windows.Forms.Padding(2);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(142, 20);
            this.textBox5.TabIndex = 59;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(102, 161);
            this.textBox6.Margin = new System.Windows.Forms.Padding(2);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(142, 20);
            this.textBox6.TabIndex = 60;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(102, 184);
            this.textBox7.Margin = new System.Windows.Forms.Padding(2);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(142, 20);
            this.textBox7.TabIndex = 61;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(102, 207);
            this.textBox8.Margin = new System.Windows.Forms.Padding(2);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(142, 20);
            this.textBox8.TabIndex = 62;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(102, 228);
            this.textBox9.Margin = new System.Windows.Forms.Padding(2);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(142, 20);
            this.textBox9.TabIndex = 63;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Purdue University Airfield",
            "Indianapolis International Airport"});
            this.comboBox1.Location = new System.Drawing.Point(291, 47);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(2);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(134, 21);
            this.comboBox1.TabIndex = 64;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "Purdue University Airfield",
            "Indianapolis International Airport"});
            this.comboBox2.Location = new System.Drawing.Point(291, 73);
            this.comboBox2.Margin = new System.Windows.Forms.Padding(2);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(134, 21);
            this.comboBox2.TabIndex = 65;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(30, 291);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(188, 25);
            this.button1.TabIndex = 67;
            this.button1.Text = "Clear Form";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(399, 291);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(221, 25);
            this.button2.TabIndex = 68;
            this.button2.Text = "Confirm Flight";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(247, 98);
            this.button3.Margin = new System.Windows.Forms.Padding(2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(177, 23);
            this.button3.TabIndex = 69;
            this.button3.Text = "Check Availablity";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // A1
            // 
            this.A1.AutoSize = true;
            this.A1.Location = new System.Drawing.Point(444, 49);
            this.A1.Margin = new System.Windows.Forms.Padding(2);
            this.A1.Name = "A1";
            this.A1.Size = new System.Drawing.Size(38, 17);
            this.A1.TabIndex = 70;
            this.A1.TabStop = true;
            this.A1.Text = "A1";
            this.A1.UseVisualStyleBackColor = true;
            // 
            // B1
            // 
            this.B1.AutoSize = true;
            this.B1.Location = new System.Drawing.Point(444, 71);
            this.B1.Margin = new System.Windows.Forms.Padding(2);
            this.B1.Name = "B1";
            this.B1.Size = new System.Drawing.Size(38, 17);
            this.B1.TabIndex = 70;
            this.B1.TabStop = true;
            this.B1.Text = "B1";
            this.B1.UseVisualStyleBackColor = true;
            // 
            // C1
            // 
            this.C1.AutoSize = true;
            this.C1.Location = new System.Drawing.Point(444, 91);
            this.C1.Margin = new System.Windows.Forms.Padding(2);
            this.C1.Name = "C1";
            this.C1.Size = new System.Drawing.Size(38, 17);
            this.C1.TabIndex = 70;
            this.C1.TabStop = true;
            this.C1.Text = "C1";
            this.C1.UseVisualStyleBackColor = true;
            // 
            // D1
            // 
            this.D1.AutoSize = true;
            this.D1.Location = new System.Drawing.Point(444, 110);
            this.D1.Margin = new System.Windows.Forms.Padding(2);
            this.D1.Name = "D1";
            this.D1.Size = new System.Drawing.Size(39, 17);
            this.D1.TabIndex = 70;
            this.D1.TabStop = true;
            this.D1.Text = "D1";
            this.D1.UseVisualStyleBackColor = true;
            // 
            // E1
            // 
            this.E1.AutoSize = true;
            this.E1.Location = new System.Drawing.Point(444, 130);
            this.E1.Margin = new System.Windows.Forms.Padding(2);
            this.E1.Name = "E1";
            this.E1.Size = new System.Drawing.Size(38, 17);
            this.E1.TabIndex = 70;
            this.E1.TabStop = true;
            this.E1.Text = "E1";
            this.E1.UseVisualStyleBackColor = true;
            // 
            // F1
            // 
            this.F1.AutoSize = true;
            this.F1.Location = new System.Drawing.Point(444, 149);
            this.F1.Margin = new System.Windows.Forms.Padding(2);
            this.F1.Name = "F1";
            this.F1.Size = new System.Drawing.Size(37, 17);
            this.F1.TabIndex = 70;
            this.F1.TabStop = true;
            this.F1.Text = "F1";
            this.F1.UseVisualStyleBackColor = true;
            // 
            // G1
            // 
            this.G1.AutoSize = true;
            this.G1.Location = new System.Drawing.Point(444, 169);
            this.G1.Margin = new System.Windows.Forms.Padding(2);
            this.G1.Name = "G1";
            this.G1.Size = new System.Drawing.Size(39, 17);
            this.G1.TabIndex = 70;
            this.G1.TabStop = true;
            this.G1.Text = "G1";
            this.G1.UseVisualStyleBackColor = true;
            // 
            // H1
            // 
            this.H1.AutoSize = true;
            this.H1.Location = new System.Drawing.Point(444, 188);
            this.H1.Margin = new System.Windows.Forms.Padding(2);
            this.H1.Name = "H1";
            this.H1.Size = new System.Drawing.Size(39, 17);
            this.H1.TabIndex = 70;
            this.H1.TabStop = true;
            this.H1.Text = "H1";
            this.H1.UseVisualStyleBackColor = true;
            // 
            // I1
            // 
            this.I1.AutoSize = true;
            this.I1.Location = new System.Drawing.Point(444, 206);
            this.I1.Margin = new System.Windows.Forms.Padding(2);
            this.I1.Name = "I1";
            this.I1.Size = new System.Drawing.Size(34, 17);
            this.I1.TabIndex = 70;
            this.I1.TabStop = true;
            this.I1.Text = "I1";
            this.I1.UseVisualStyleBackColor = true;
            // 
            // J1
            // 
            this.J1.AutoSize = true;
            this.J1.Location = new System.Drawing.Point(444, 226);
            this.J1.Margin = new System.Windows.Forms.Padding(2);
            this.J1.Name = "J1";
            this.J1.Size = new System.Drawing.Size(36, 17);
            this.J1.TabIndex = 70;
            this.J1.TabStop = true;
            this.J1.Text = "J1";
            this.J1.UseVisualStyleBackColor = true;
            // 
            // J2
            // 
            this.J2.AutoSize = true;
            this.J2.Location = new System.Drawing.Point(484, 225);
            this.J2.Margin = new System.Windows.Forms.Padding(2);
            this.J2.Name = "J2";
            this.J2.Size = new System.Drawing.Size(36, 17);
            this.J2.TabIndex = 71;
            this.J2.TabStop = true;
            this.J2.Text = "J2";
            this.J2.UseVisualStyleBackColor = true;
            // 
            // I2
            // 
            this.I2.AutoSize = true;
            this.I2.Location = new System.Drawing.Point(484, 205);
            this.I2.Margin = new System.Windows.Forms.Padding(2);
            this.I2.Name = "I2";
            this.I2.Size = new System.Drawing.Size(34, 17);
            this.I2.TabIndex = 72;
            this.I2.TabStop = true;
            this.I2.Text = "I2";
            this.I2.UseVisualStyleBackColor = true;
            // 
            // H2
            // 
            this.H2.AutoSize = true;
            this.H2.Location = new System.Drawing.Point(484, 188);
            this.H2.Margin = new System.Windows.Forms.Padding(2);
            this.H2.Name = "H2";
            this.H2.Size = new System.Drawing.Size(39, 17);
            this.H2.TabIndex = 73;
            this.H2.TabStop = true;
            this.H2.Text = "H2";
            this.H2.UseVisualStyleBackColor = true;
            // 
            // G2
            // 
            this.G2.AutoSize = true;
            this.G2.Location = new System.Drawing.Point(484, 168);
            this.G2.Margin = new System.Windows.Forms.Padding(2);
            this.G2.Name = "G2";
            this.G2.Size = new System.Drawing.Size(39, 17);
            this.G2.TabIndex = 74;
            this.G2.TabStop = true;
            this.G2.Text = "G2";
            this.G2.UseVisualStyleBackColor = true;
            // 
            // F2
            // 
            this.F2.AutoSize = true;
            this.F2.Location = new System.Drawing.Point(484, 149);
            this.F2.Margin = new System.Windows.Forms.Padding(2);
            this.F2.Name = "F2";
            this.F2.Size = new System.Drawing.Size(37, 17);
            this.F2.TabIndex = 75;
            this.F2.TabStop = true;
            this.F2.Text = "F2";
            this.F2.UseVisualStyleBackColor = true;
            // 
            // E2
            // 
            this.E2.AutoSize = true;
            this.E2.Location = new System.Drawing.Point(484, 129);
            this.E2.Margin = new System.Windows.Forms.Padding(2);
            this.E2.Name = "E2";
            this.E2.Size = new System.Drawing.Size(38, 17);
            this.E2.TabIndex = 76;
            this.E2.TabStop = true;
            this.E2.Text = "E2";
            this.E2.UseVisualStyleBackColor = true;
            // 
            // D2
            // 
            this.D2.AutoSize = true;
            this.D2.Location = new System.Drawing.Point(484, 110);
            this.D2.Margin = new System.Windows.Forms.Padding(2);
            this.D2.Name = "D2";
            this.D2.Size = new System.Drawing.Size(39, 17);
            this.D2.TabIndex = 77;
            this.D2.TabStop = true;
            this.D2.Text = "D2";
            this.D2.UseVisualStyleBackColor = true;
            // 
            // C2
            // 
            this.C2.AutoSize = true;
            this.C2.Location = new System.Drawing.Point(484, 90);
            this.C2.Margin = new System.Windows.Forms.Padding(2);
            this.C2.Name = "C2";
            this.C2.Size = new System.Drawing.Size(38, 17);
            this.C2.TabIndex = 78;
            this.C2.TabStop = true;
            this.C2.Text = "C2";
            this.C2.UseVisualStyleBackColor = true;
            // 
            // B2
            // 
            this.B2.AutoSize = true;
            this.B2.Location = new System.Drawing.Point(484, 71);
            this.B2.Margin = new System.Windows.Forms.Padding(2);
            this.B2.Name = "B2";
            this.B2.Size = new System.Drawing.Size(38, 17);
            this.B2.TabIndex = 79;
            this.B2.TabStop = true;
            this.B2.Text = "B2";
            this.B2.UseVisualStyleBackColor = true;
            
            // 
            // A2
            // 
            this.A2.AutoSize = true;
            this.A2.Location = new System.Drawing.Point(484, 48);
            this.A2.Margin = new System.Windows.Forms.Padding(2);
            this.A2.Name = "A2";
            this.A2.Size = new System.Drawing.Size(38, 17);
            this.A2.TabIndex = 80;
            this.A2.TabStop = true;
            this.A2.Text = "A2";
            this.A2.UseVisualStyleBackColor = true;
            // 
            // J4
            // 
            this.J4.AutoSize = true;
            this.J4.Location = new System.Drawing.Point(564, 225);
            this.J4.Margin = new System.Windows.Forms.Padding(2);
            this.J4.Name = "J4";
            this.J4.Size = new System.Drawing.Size(36, 17);
            this.J4.TabIndex = 91;
            this.J4.TabStop = true;
            this.J4.Text = "J4";
            this.J4.UseVisualStyleBackColor = true;
            // 
            // I4
            // 
            this.I4.AutoSize = true;
            this.I4.Location = new System.Drawing.Point(564, 205);
            this.I4.Margin = new System.Windows.Forms.Padding(2);
            this.I4.Name = "I4";
            this.I4.Size = new System.Drawing.Size(34, 17);
            this.I4.TabIndex = 92;
            this.I4.TabStop = true;
            this.I4.Text = "I4";
            this.I4.UseVisualStyleBackColor = true;
            // 
            // H4
            // 
            this.H4.AutoSize = true;
            this.H4.Location = new System.Drawing.Point(564, 188);
            this.H4.Margin = new System.Windows.Forms.Padding(2);
            this.H4.Name = "H4";
            this.H4.Size = new System.Drawing.Size(39, 17);
            this.H4.TabIndex = 93;
            this.H4.TabStop = true;
            this.H4.Text = "H4";
            this.H4.UseVisualStyleBackColor = true;
            // 
            // G4
            // 
            this.G4.AutoSize = true;
            this.G4.Location = new System.Drawing.Point(564, 168);
            this.G4.Margin = new System.Windows.Forms.Padding(2);
            this.G4.Name = "G4";
            this.G4.Size = new System.Drawing.Size(39, 17);
            this.G4.TabIndex = 94;
            this.G4.TabStop = true;
            this.G4.Text = "G4";
            this.G4.UseVisualStyleBackColor = true;
            // 
            // F4
            // 
            this.F4.AutoSize = true;
            this.F4.Location = new System.Drawing.Point(564, 149);
            this.F4.Margin = new System.Windows.Forms.Padding(2);
            this.F4.Name = "F4";
            this.F4.Size = new System.Drawing.Size(37, 17);
            this.F4.TabIndex = 95;
            this.F4.TabStop = true;
            this.F4.Text = "F4";
            this.F4.UseVisualStyleBackColor = true;
            // 
            // E4
            // 
            this.E4.AutoSize = true;
            this.E4.Location = new System.Drawing.Point(564, 129);
            this.E4.Margin = new System.Windows.Forms.Padding(2);
            this.E4.Name = "E4";
            this.E4.Size = new System.Drawing.Size(38, 17);
            this.E4.TabIndex = 96;
            this.E4.TabStop = true;
            this.E4.Text = "E4";
            this.E4.UseVisualStyleBackColor = true;
            // 
            // D4
            // 
            this.D4.AutoSize = true;
            this.D4.Location = new System.Drawing.Point(564, 110);
            this.D4.Margin = new System.Windows.Forms.Padding(2);
            this.D4.Name = "D4";
            this.D4.Size = new System.Drawing.Size(39, 17);
            this.D4.TabIndex = 97;
            this.D4.TabStop = true;
            this.D4.Text = "D4";
            this.D4.UseVisualStyleBackColor = true;
            // 
            // C4
            // 
            this.C4.AutoSize = true;
            this.C4.Location = new System.Drawing.Point(564, 90);
            this.C4.Margin = new System.Windows.Forms.Padding(2);
            this.C4.Name = "C4";
            this.C4.Size = new System.Drawing.Size(38, 17);
            this.C4.TabIndex = 98;
            this.C4.TabStop = true;
            this.C4.Text = "C4";
            this.C4.UseVisualStyleBackColor = true;
            // 
            // B4
            // 
            this.B4.AutoSize = true;
            this.B4.Location = new System.Drawing.Point(564, 71);
            this.B4.Margin = new System.Windows.Forms.Padding(2);
            this.B4.Name = "B4";
            this.B4.Size = new System.Drawing.Size(38, 17);
            this.B4.TabIndex = 99;
            this.B4.TabStop = true;
            this.B4.Text = "B4";
            this.B4.UseVisualStyleBackColor = true;
            // 
            // A4
            // 
            this.A4.AutoSize = true;
            this.A4.Location = new System.Drawing.Point(564, 48);
            this.A4.Margin = new System.Windows.Forms.Padding(2);
            this.A4.Name = "A4";
            this.A4.Size = new System.Drawing.Size(38, 17);
            this.A4.TabIndex = 100;
            this.A4.TabStop = true;
            this.A4.Text = "A4";
            this.A4.UseVisualStyleBackColor = true;
            // 
            // J3
            // 
            this.J3.AutoSize = true;
            this.J3.Location = new System.Drawing.Point(524, 225);
            this.J3.Margin = new System.Windows.Forms.Padding(2);
            this.J3.Name = "J3";
            this.J3.Size = new System.Drawing.Size(36, 17);
            this.J3.TabIndex = 89;
            this.J3.TabStop = true;
            this.J3.Text = "J3";
            this.J3.UseVisualStyleBackColor = true;
            // 
            // I3
            // 
            this.I3.AutoSize = true;
            this.I3.Location = new System.Drawing.Point(524, 205);
            this.I3.Margin = new System.Windows.Forms.Padding(2);
            this.I3.Name = "I3";
            this.I3.Size = new System.Drawing.Size(34, 17);
            this.I3.TabIndex = 88;
            this.I3.TabStop = true;
            this.I3.Text = "I3";
            this.I3.UseVisualStyleBackColor = true;
            // 
            // H3
            // 
            this.H3.AutoSize = true;
            this.H3.Location = new System.Drawing.Point(524, 188);
            this.H3.Margin = new System.Windows.Forms.Padding(2);
            this.H3.Name = "H3";
            this.H3.Size = new System.Drawing.Size(39, 17);
            this.H3.TabIndex = 87;
            this.H3.TabStop = true;
            this.H3.Text = "H3";
            this.H3.UseVisualStyleBackColor = true;
            // 
            // G3
            // 
            this.G3.AutoSize = true;
            this.G3.Location = new System.Drawing.Point(524, 168);
            this.G3.Margin = new System.Windows.Forms.Padding(2);
            this.G3.Name = "G3";
            this.G3.Size = new System.Drawing.Size(39, 17);
            this.G3.TabIndex = 86;
            this.G3.TabStop = true;
            this.G3.Text = "G3";
            this.G3.UseVisualStyleBackColor = true;
            // 
            // F3
            // 
            this.F3.AutoSize = true;
            this.F3.Location = new System.Drawing.Point(524, 149);
            this.F3.Margin = new System.Windows.Forms.Padding(2);
            this.F3.Name = "F3";
            this.F3.Size = new System.Drawing.Size(37, 17);
            this.F3.TabIndex = 85;
            this.F3.TabStop = true;
            this.F3.Text = "F3";
            this.F3.UseVisualStyleBackColor = true;
            // 
            // E3
            // 
            this.E3.AutoSize = true;
            this.E3.Location = new System.Drawing.Point(524, 129);
            this.E3.Margin = new System.Windows.Forms.Padding(2);
            this.E3.Name = "E3";
            this.E3.Size = new System.Drawing.Size(38, 17);
            this.E3.TabIndex = 84;
            this.E3.TabStop = true;
            this.E3.Text = "E3";
            this.E3.UseVisualStyleBackColor = true;
            // 
            // D3
            // 
            this.D3.AutoSize = true;
            this.D3.Location = new System.Drawing.Point(524, 110);
            this.D3.Margin = new System.Windows.Forms.Padding(2);
            this.D3.Name = "D3";
            this.D3.Size = new System.Drawing.Size(39, 17);
            this.D3.TabIndex = 83;
            this.D3.TabStop = true;
            this.D3.Text = "D3";
            this.D3.UseVisualStyleBackColor = true;
            // 
            // C3
            // 
            this.C3.AutoSize = true;
            this.C3.Location = new System.Drawing.Point(524, 90);
            this.C3.Margin = new System.Windows.Forms.Padding(2);
            this.C3.Name = "C3";
            this.C3.Size = new System.Drawing.Size(38, 17);
            this.C3.TabIndex = 82;
            this.C3.TabStop = true;
            this.C3.Text = "C3";
            this.C3.UseVisualStyleBackColor = true;
            // 
            // B3
            // 
            this.B3.AutoSize = true;
            this.B3.Location = new System.Drawing.Point(524, 71);
            this.B3.Margin = new System.Windows.Forms.Padding(2);
            this.B3.Name = "B3";
            this.B3.Size = new System.Drawing.Size(38, 17);
            this.B3.TabIndex = 90;
            this.B3.TabStop = true;
            this.B3.Text = "B3";
            this.B3.UseVisualStyleBackColor = true;
            // 
            // A3
            // 
            this.A3.AutoSize = true;
            this.A3.Location = new System.Drawing.Point(524, 48);
            this.A3.Margin = new System.Windows.Forms.Padding(2);
            this.A3.Name = "A3";
            this.A3.Size = new System.Drawing.Size(38, 17);
            this.A3.TabIndex = 81;
            this.A3.TabStop = true;
            this.A3.Text = "A3";
            this.A3.UseVisualStyleBackColor = true;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(296, 126);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(13, 13);
            this.label16.TabIndex = 101;
            this.label16.Text = "0";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(459, 258);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(79, 13);
            this.label17.TabIndex = 102;
            this.label17.Text = "Your Selection:";
            // 
            // seatLabel
            // 
            this.seatLabel.AutoSize = true;
            this.seatLabel.Location = new System.Drawing.Point(535, 258);
            this.seatLabel.Name = "seatLabel";
            this.seatLabel.Size = new System.Drawing.Size(13, 13);
            this.seatLabel.TabIndex = 103;
            this.seatLabel.Text = "0";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(631, 324);
            this.Controls.Add(this.seatLabel);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.J4);
            this.Controls.Add(this.I4);
            this.Controls.Add(this.H4);
            this.Controls.Add(this.G4);
            this.Controls.Add(this.F4);
            this.Controls.Add(this.E4);
            this.Controls.Add(this.D4);
            this.Controls.Add(this.C4);
            this.Controls.Add(this.B4);
            this.Controls.Add(this.A4);
            this.Controls.Add(this.J3);
            this.Controls.Add(this.I3);
            this.Controls.Add(this.H3);
            this.Controls.Add(this.G3);
            this.Controls.Add(this.F3);
            this.Controls.Add(this.E3);
            this.Controls.Add(this.D3);
            this.Controls.Add(this.C3);
            this.Controls.Add(this.B3);
            this.Controls.Add(this.A3);
            this.Controls.Add(this.J2);
            this.Controls.Add(this.I2);
            this.Controls.Add(this.H2);
            this.Controls.Add(this.G2);
            this.Controls.Add(this.F2);
            this.Controls.Add(this.E2);
            this.Controls.Add(this.D2);
            this.Controls.Add(this.C2);
            this.Controls.Add(this.B2);
            this.Controls.Add(this.A2);
            this.Controls.Add(this.J1);
            this.Controls.Add(this.I1);
            this.Controls.Add(this.H1);
            this.Controls.Add(this.G1);
            this.Controls.Add(this.F1);
            this.Controls.Add(this.E1);
            this.Controls.Add(this.D1);
            this.Controls.Add(this.C1);
            this.Controls.Add(this.B1);
            this.Controls.Add(this.A1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Purdue Airlines Reservation System";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.RadioButton A1;
        private System.Windows.Forms.RadioButton B1;
        private System.Windows.Forms.RadioButton C1;
        private System.Windows.Forms.RadioButton D1;
        private System.Windows.Forms.RadioButton E1;
        private System.Windows.Forms.RadioButton F1;
        private System.Windows.Forms.RadioButton G1;
        private System.Windows.Forms.RadioButton H1;
        private System.Windows.Forms.RadioButton I1;
        private System.Windows.Forms.RadioButton J1;
        private System.Windows.Forms.RadioButton J2;
        private System.Windows.Forms.RadioButton I2;
        private System.Windows.Forms.RadioButton H2;
        private System.Windows.Forms.RadioButton G2;
        private System.Windows.Forms.RadioButton F2;
        private System.Windows.Forms.RadioButton E2;
        private System.Windows.Forms.RadioButton D2;
        private System.Windows.Forms.RadioButton C2;
        private System.Windows.Forms.RadioButton B2;
        private System.Windows.Forms.RadioButton A2;
        private System.Windows.Forms.RadioButton J4;
        private System.Windows.Forms.RadioButton I4;
        private System.Windows.Forms.RadioButton H4;
        private System.Windows.Forms.RadioButton G4;
        private System.Windows.Forms.RadioButton F4;
        private System.Windows.Forms.RadioButton E4;
        private System.Windows.Forms.RadioButton D4;
        private System.Windows.Forms.RadioButton C4;
        private System.Windows.Forms.RadioButton B4;
        private System.Windows.Forms.RadioButton A4;
        private System.Windows.Forms.RadioButton J3;
        private System.Windows.Forms.RadioButton I3;
        private System.Windows.Forms.RadioButton H3;
        private System.Windows.Forms.RadioButton G3;
        private System.Windows.Forms.RadioButton F3;
        private System.Windows.Forms.RadioButton E3;
        private System.Windows.Forms.RadioButton D3;
        private System.Windows.Forms.RadioButton C3;
        private System.Windows.Forms.RadioButton B3;
        private System.Windows.Forms.RadioButton A3;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label seatLabel;
    }
}

